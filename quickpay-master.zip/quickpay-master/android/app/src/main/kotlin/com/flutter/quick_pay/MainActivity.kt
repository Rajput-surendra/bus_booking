package com.flutter.quick_pay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
