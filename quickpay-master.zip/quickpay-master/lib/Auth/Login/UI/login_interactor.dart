class LoginInteractor {
  void loginWithMobile(String isoCode, String mobileNumber) {}
  void signUp() {}
  void forgotPassword() {}
}
