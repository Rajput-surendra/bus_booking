class ForgotPasswordInteractor {
  void forgotPassword() {}
}
