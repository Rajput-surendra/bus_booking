class Assets {
  static const String appLogo = 'assets/logo.png';
  static const String appIcon = 'assets/app_icon.png';
  static const String background = 'assets/imgs/Layer 1672.png';
  static const String phoneIcon = 'assets/icons/ic_phone.png';
  static const String passwordIcon = 'assets/icons/ic_password copy.png';
  static const String accountIcon = 'assets/icons/ic_person.png';
  static const String emailIcon = 'assets/icons/ic_email.png';
}
