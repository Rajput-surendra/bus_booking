import 'package:flutter/material.dart';

Color scaffoldBackgroundColor = Colors.white;
Color white = Colors.white;
Color blackColor = Colors.black;
Color? hintColor = Colors.grey[400];
Color transparentColor = Colors.transparent;
// Color cartCountBackgroundColor = Colors.red;
Color cartCountBackgroundColor = Color(0xffEBECF0);
Color newNotificationColor = Colors.green;
Color background = Color(0xffEBECF0);
Color primary = Color(0xffE84E4E);





