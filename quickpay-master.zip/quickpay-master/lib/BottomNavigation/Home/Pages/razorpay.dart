import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RazorpayPayment extends StatefulWidget {
  const RazorpayPayment({Key? key}) : super(key: key);

  @override
  State<RazorpayPayment> createState() => _RazorpayPaymentState();
}

class _RazorpayPaymentState extends State<RazorpayPayment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Column(children: [

      ],) ,
    );
  }
}
