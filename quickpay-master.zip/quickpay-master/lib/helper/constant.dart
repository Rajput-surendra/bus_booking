final String imageUrl = 'https://developmentalphawizz.com/financego/';
final String baseUrl = 'https://developmentalphawizz.com/financego/app/v1/api/';
final Uri getUserLoginApi = Uri.parse(baseUrl + 'v_send_otp');
final Uri getUserSignUpApi = Uri.parse(baseUrl + 'user_register');
final Uri getVerifyUserApi = Uri.parse(baseUrl + 'v_verify_otp');
final Uri setProfile = Uri.parse(baseUrl + 'get_profile');
final Uri getSetting = Uri.parse(baseUrl + 'get_settings');

